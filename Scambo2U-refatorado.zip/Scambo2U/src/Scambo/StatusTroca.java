package Scambo;

/**
 * Enum que representa os possíveis estados de uma Troca.
 */
public enum StatusTroca {

    PENDENTE("Pendente"),       // troca proposta, aguardando confirmação
    CONFIRMADA("Confirmada"),   // ambas as partes aceitaram
    CANCELADA("Cancelada"),     // uma das partes cancelou
    CONCLUIDA("Concluída");     // troca efetivada com sucesso

    private final String descricao;

    StatusTroca(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
