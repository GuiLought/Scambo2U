package Scambo;

/**
 * Enum que representa as categorias disponíveis para um produto.
 * Usar enum evita erros de digitação e facilita comparações.
 */
public enum Categoria {

    ELETRONICOS("Eletrônicos"),
    MODA_E_ACESSORIOS("Moda e Acessórios"),
    CASA_E_DECORACAO("Casa e Decoração"),
    ESPORTES("Esportes"),
    BRINQUEDOS_E_JOGOS("Brinquedos e Jogos"),
    LIVROS_E_PAPELARIA("Livros e Papelaria"),
    MUSICA_E_INSTRUMENTOS("Música e Instrumentos"),
    AUTOMOVEIS_E_PECAS("Automóveis e Peças"),
    FERRAMENTAS("Ferramentas"),
    ACESSORIOS_PARA_ANIMAIS("Acessórios para Animais"),
    OUTROS("Outros");

    // Nome amigável para exibir na tela
    private final String descricao;

    Categoria(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    /**
     * Retorna uma string numerada com todas as categorias,
     * pronta para exibir no JOptionPane.
     */
    public static String listarCategorias() {
        StringBuilder sb = new StringBuilder("Escolha a categoria:\n\n");
        Categoria[] valores = Categoria.values();
        for (int i = 0; i < valores.length; i++) {
            sb.append((i + 1)).append("- ").append(valores[i].getDescricao()).append("\n");
        }
        return sb.toString();
    }

    /**
     * Retorna a categoria correspondente ao número escolhido pelo usuário (1-based).
     * Retorna null se o número for inválido.
     */
    public static Categoria fromOpcao(int opcao) {
        Categoria[] valores = Categoria.values();
        if (opcao >= 1 && opcao <= valores.length) {
            return valores[opcao - 1];
        }
        return null;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
