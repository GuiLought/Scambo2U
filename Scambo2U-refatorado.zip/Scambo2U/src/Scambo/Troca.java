package Scambo;

/**
 * Classe que representa uma Troca entre dois Proprietários.
 *
 * Uma troca envolve:
 *   - Um proponente (quem inicia a troca) e seu produto oferecido
 *   - Um receptor (quem recebe a proposta) e o produto que o proponente deseja
 *
 * O fluxo típico é:
 *   1. Troca criada com status PENDENTE
 *   2. Receptor aceita → status vai para CONFIRMADA → confirmar() efetiva a troca
 *   3. Qualquer um cancela → status vai para CANCELADA
 */
public class Troca {

    // ─── Atributos ────────────────────────────────────────────────
    private final Proprietario proponente;       // quem propõe a troca
    private final Produto      produtoOfertado;  // produto que o proponente oferece

    private final Proprietario receptor;         // quem recebe a proposta
    private final Produto      produtoDesejado;  // produto que o proponente quer receber

    private StatusTroca status;

    // ─── Construtor ───────────────────────────────────────────────

    /**
     * Cria uma nova proposta de troca com status PENDENTE.
     *
     * @param proponente      Proprietário que inicia a troca
     * @param produtoOfertado Produto que o proponente oferece
     * @param receptor        Proprietário que possui o produto desejado
     * @param produtoDesejado Produto que o proponente quer obter
     */
    public Troca(Proprietario proponente, Produto produtoOfertado,
                 Proprietario receptor,   Produto produtoDesejado) {

        if (proponente == null || receptor == null) {
            throw new IllegalArgumentException("Proponente e receptor não podem ser nulos.");
        }
        if (produtoOfertado == null || produtoDesejado == null) {
            throw new IllegalArgumentException("Os produtos da troca não podem ser nulos.");
        }
        if (proponente == receptor) {
            throw new IllegalArgumentException("Um proprietário não pode trocar consigo mesmo.");
        }

        this.proponente      = proponente;
        this.produtoOfertado = produtoOfertado;
        this.receptor        = receptor;
        this.produtoDesejado = produtoDesejado;
        this.status          = StatusTroca.PENDENTE;
    }

    // ─── Getters ──────────────────────────────────────────────────

    public Proprietario getProponente()      { return proponente; }
    public Produto      getProdutoOfertado() { return produtoOfertado; }
    public Proprietario getReceptor()        { return receptor; }
    public Produto      getProdutoDesejado() { return produtoDesejado; }
    public StatusTroca  getStatus()          { return status; }

    // ─── Métodos de negócio ───────────────────────────────────────

    /**
     * Confirma e efetiva a troca.
     * Desconta 1 unidade de cada produto e marca como CONCLUÍDA.
     *
     * Lança exceção se algum produto não estiver disponível
     * ou se a troca não estiver no estado PENDENTE.
     */
    public void confirmar() {
        if (status != StatusTroca.PENDENTE) {
            throw new IllegalStateException("Só é possível confirmar uma troca PENDENTE. Status atual: " + status);
        }
        if (!produtoOfertado.isDisponivel()) {
            throw new IllegalStateException("Produto ofertado '" + produtoOfertado.getNome() + "' não está disponível.");
        }
        if (!produtoDesejado.isDisponivel()) {
            throw new IllegalStateException("Produto desejado '" + produtoDesejado.getNome() + "' não está disponível.");
        }

        // Efetiva a troca: desconta estoque dos dois lados
        produtoOfertado.registrarTroca();
        produtoDesejado.registrarTroca();

        this.status = StatusTroca.CONCLUIDA;
    }

    /**
     * Cancela a troca. Pode ser chamado por qualquer uma das partes.
     * Lança exceção se a troca já foi concluída.
     */
    public void cancelar() {
        if (status == StatusTroca.CONCLUIDA) {
            throw new IllegalStateException("Não é possível cancelar uma troca já concluída.");
        }
        this.status = StatusTroca.CANCELADA;
    }

    // ─── Exibição ─────────────────────────────────────────────────

    /**
     * Retorna um resumo da troca para exibição no JOptionPane.
     */
    public String toStringDetalhado() {
        return "=== Detalhes da Troca ===\n\n"
             + "Proponente : " + proponente.getNome()      + "\n"
             + "Oferece    : " + produtoOfertado.getNome() + "\n\n"
             + "Receptor   : " + receptor.getNome()        + "\n"
             + "Deseja     : " + produtoDesejado.getNome() + "\n\n"
             + "Status     : " + status.getDescricao();
    }

    @Override
    public String toString() {
        return proponente.getNome() + " → " + produtoOfertado.getNome()
             + "  |  "
             + receptor.getNome()   + " → " + produtoDesejado.getNome()
             + "  [" + status + "]";
    }
}
