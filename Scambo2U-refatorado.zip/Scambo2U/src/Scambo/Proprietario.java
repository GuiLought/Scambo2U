package Scambo;

/**
 * Classe que representa um Proprietário (usuário) no sistema Scambo2U.
 *
 * Cada proprietário possui seus dados pessoais e seu próprio Estoque,
 * onde ficam os produtos que ele oferece para troca.
 */
public class Proprietario {

    // ─── Atributos ────────────────────────────────────────────────
    private String  nome;
    private String  email;
    private String  telefone;
    private Estoque estoque;

    // ─── Construtor ───────────────────────────────────────────────

    /**
     * Cria um novo proprietário.
     * O estoque começa vazio e é criado automaticamente.
     *
     * @param nome     Nome completo do proprietário
     * @param email    E-mail de contato
     * @param telefone Telefone de contato
     */
    public Proprietario(String nome, String email, String telefone) {
        setNome(nome);
        setEmail(email);
        setTelefone(telefone);
        this.estoque = new Estoque(); // cada proprietário começa com estoque vazio
    }

    // ─── Getters e Setters ────────────────────────────────────────

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome do proprietário não pode ser vazio.");
        }
        this.nome = nome.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("E-mail inválido.");
        }
        this.email = email.trim();
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        if (telefone == null || telefone.trim().isEmpty()) {
            throw new IllegalArgumentException("O telefone não pode ser vazio.");
        }
        this.telefone = telefone.trim();
    }

    public Estoque getEstoque() {
        return estoque;
    }

    // ─── Métodos de conveniência ──────────────────────────────────

    /**
     * Atalho para adicionar um produto direto no estoque do proprietário.
     */
    public void adicionarProduto(Produto produto) {
        estoque.adicionarProduto(produto);
    }

    /**
     * Atalho para remover um produto do estoque pelo nome.
     *
     * @return true se removido, false se não encontrado.
     */
    public boolean removerProduto(String nomeProduto) {
        return estoque.removerPorNome(nomeProduto);
    }

    /**
     * Verifica se este proprietário possui determinado produto disponível.
     */
    public boolean temProdutoDisponivel(String nomeProduto) {
        Produto p = estoque.buscarPorNome(nomeProduto);
        return p != null && p.isDisponivel();
    }

    // ─── Exibição ─────────────────────────────────────────────────

    /**
     * Retorna uma ficha resumida do proprietário para exibição.
     */
    public String toStringDetalhado() {
        return "Nome: "     + nome                              + "\n"
             + "E-mail: "   + email                             + "\n"
             + "Telefone: " + telefone                          + "\n"
             + "Produtos: " + estoque.totalProdutos() + " cadastrado(s)";
    }

    @Override
    public String toString() {
        return nome + " (" + email + ")";
    }
}
