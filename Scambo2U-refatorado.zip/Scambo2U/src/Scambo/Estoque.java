package Scambo;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe responsável por gerenciar a coleção de produtos de um Proprietário.
 *
 * Centraliza todas as operações de busca, adição e remoção,
 * mantendo a lógica separada da interface gráfica.
 */
public class Estoque {

    // Lista interna de produtos — só acessível pelos métodos desta classe
    private final ArrayList<Produto> produtos;

    // ─── Construtor ───────────────────────────────────────────────

    public Estoque() {
        this.produtos = new ArrayList<>();
    }

    // ─── Operações principais ─────────────────────────────────────

    /**
     * Adiciona um produto ao estoque.
     * Se já existir um produto com o mesmo nome, soma a quantidade.
     */
    public void adicionarProduto(Produto produto) {
        Produto existente = buscarPorNome(produto.getNome());

        if (existente != null) {
            // Produto já cadastrado: só aumenta a quantidade
            existente.setQuantidade(existente.getQuantidade() + produto.getQuantidade());
        } else {
            produtos.add(produto);
        }
    }

    /**
     * Remove um produto do estoque pelo nome (ignora maiúsculas/minúsculas).
     *
     * @return true se removido com sucesso, false se não encontrado.
     */
    public boolean removerPorNome(String nome) {
        Produto produto = buscarPorNome(nome);

        if (produto != null) {
            produtos.remove(produto);
            return true;
        }

        return false;
    }

    /**
     * Busca um produto pelo nome exato (ignora maiúsculas/minúsculas).
     *
     * @return O produto encontrado, ou null se não existir.
     */
    public Produto buscarPorNome(String nome) {
        for (Produto p : produtos) {
            if (p.getNome().equalsIgnoreCase(nome)) {
                return p;
            }
        }
        return null;
    }

    /**
     * Busca todos os produtos de uma determinada categoria.
     *
     * @return Lista (pode ser vazia) com os produtos encontrados.
     */
    public List<Produto> buscarPorCategoria(Categoria categoria) {
        List<Produto> resultado = new ArrayList<>();

        for (Produto p : produtos) {
            if (p.getCategoria() == categoria) {
                resultado.add(p);
            }
        }

        return resultado;
    }

    /**
     * Retorna apenas os produtos que ainda estão disponíveis (quantidade > 0).
     */
    public List<Produto> listarDisponiveis() {
        List<Produto> disponiveis = new ArrayList<>();

        for (Produto p : produtos) {
            if (p.isDisponivel()) {
                disponiveis.add(p);
            }
        }

        return disponiveis;
    }

    // ─── Informações do estoque ───────────────────────────────────

    /**
     * Verifica se o estoque está vazio.
     */
    public boolean isEmpty() {
        return produtos.isEmpty();
    }

    /**
     * Retorna o total de itens distintos cadastrados.
     */
    public int totalProdutos() {
        return produtos.size();
    }

    /**
     * Retorna a lista completa de produtos (cópia para evitar modificação externa).
     */
    public List<Produto> getTodos() {
        return new ArrayList<>(produtos);
    }

    /**
     * Monta uma string formatada com todos os produtos para exibição no JOptionPane.
     */
    public String toStringListagem() {
        if (produtos.isEmpty()) {
            return "Nenhum produto cadastrado.";
        }

        StringBuilder sb = new StringBuilder("--- Produtos em Estoque ---\n\n");

        for (int i = 0; i < produtos.size(); i++) {
            sb.append(i + 1).append(". ").append(produtos.get(i).toStringDetalhado()).append("\n\n");
        }

        sb.append("Total de produtos: ").append(produtos.size());

        return sb.toString();
    }
}
