package Scambo;

import javax.swing.JOptionPane;

/**
 * Classe principal do sistema Scambo2U.
 *
 * Responsável apenas pela interface com o usuário (menus e diálogos).
 * Toda a lógica de negócio fica nas outras classes:
 *   - Produto, Categoria → dados do produto
 *   - Proprietario       → dados do usuário
 *   - Estoque            → gerenciamento da coleção de produtos
 *   - Troca, StatusTroca → lógica de troca entre proprietários
 */
public class Main {

    // Proprietário logado na sessão atual
    // Numa versão futura, aqui poderia haver uma lista de proprietários
    private static Proprietario proprietarioAtual;

    // ─── Ponto de entrada ─────────────────────────────────────────

    public static void main(String[] args) {

        // Cadastra o proprietário ao iniciar o sistema
        proprietarioAtual = cadastrarProprietario();

        if (proprietarioAtual == null) {
            JOptionPane.showMessageDialog(null, "Cadastro cancelado. Encerrando o sistema.");
            return;
        }

        int opcao = -1;

        while (opcao != 0) {
            try {
                String input = JOptionPane.showInputDialog(null,
                        "---Scambo2U---\n"
                      + "Olá, " + proprietarioAtual.getNome() + "!\n\n"
                      + "1- Adicionar Produto\n"
                      + "2- Listar meus Produtos\n"
                      + "3- Buscar Produto por Nome\n"
                      + "4- Buscar Produto por Categoria\n"
                      + "5- Realizar Troca\n"
                      + "6- Remover Produto\n"
                      + "0- Sair\n\n"
                      + "Escolha sua opção:",
                        "Scambo2U", JOptionPane.PLAIN_MESSAGE);

                if (input == null) {
                    opcao = 0;
                } else {
                    opcao = Integer.parseInt(input.trim());

                    switch (opcao) {
                        case 1: adicionarProduto();           break;
                        case 2: listarProdutos();             break;
                        case 3: buscarPorNome();              break;
                        case 4: buscarPorCategoria();         break;
                        case 5: realizarTroca();              break;
                        case 6: removerProduto();             break;
                        case 0:
                            JOptionPane.showMessageDialog(null, "Saindo do Sistema. Até mais!");
                            break;
                        default:
                            JOptionPane.showMessageDialog(null,
                                    "Opção inválida! Tente novamente.", "ERRO",
                                    JOptionPane.ERROR_MESSAGE);
                    }
                }

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null,
                        "Entrada inválida. Por favor, digite um número.", "ERRO",
                        JOptionPane.ERROR_MESSAGE);
                opcao = -1;
            }
        }
    }

    // ─── Cadastro do Proprietário ─────────────────────────────────

    /**
     * Solicita os dados do proprietário e retorna o objeto criado.
     * Retorna null se o usuário cancelar.
     */
    private static Proprietario cadastrarProprietario() {
        try {
            String nome = JOptionPane.showInputDialog(null,
                    "Bem-vindo ao Scambo2U!\n\nDigite seu nome:", "Cadastro", JOptionPane.PLAIN_MESSAGE);
            if (nome == null) return null;

            String email = JOptionPane.showInputDialog(null,
                    "Digite seu e-mail:", "Cadastro", JOptionPane.PLAIN_MESSAGE);
            if (email == null) return null;

            String telefone = JOptionPane.showInputDialog(null,
                    "Digite seu telefone:", "Cadastro", JOptionPane.PLAIN_MESSAGE);
            if (telefone == null) return null;

            return new Proprietario(nome, email, telefone);

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Erro no cadastro: " + e.getMessage(), "ERRO",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    // ─── Opção 1: Adicionar Produto ───────────────────────────────

    private static void adicionarProduto() {
        try {
            // Nome
            String nome = JOptionPane.showInputDialog(null,
                    "Digite o nome do produto:", "Adicionar Produto", JOptionPane.PLAIN_MESSAGE);
            if (nome == null) return;

            // Categoria — exibe o enum formatado
            String inputCategoria = JOptionPane.showInputDialog(null,
                    Categoria.listarCategorias(), "Adicionar Produto", JOptionPane.PLAIN_MESSAGE);
            if (inputCategoria == null) return;

            Categoria categoria = Categoria.fromOpcao(Integer.parseInt(inputCategoria.trim()));
            if (categoria == null) {
                JOptionPane.showMessageDialog(null, "Categoria inválida.", "ERRO", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Peso
            String pesoInput = JOptionPane.showInputDialog(null,
                    "Digite o peso do produto (em kg):", "Adicionar Produto", JOptionPane.PLAIN_MESSAGE);
            if (pesoInput == null) return;
            double peso = Double.parseDouble(pesoInput.trim());

            // Tamanho
            String tamanhoInput = JOptionPane.showInputDialog(null,
                    "Digite o tamanho do produto (em cm):", "Adicionar Produto", JOptionPane.PLAIN_MESSAGE);
            if (tamanhoInput == null) return;
            double tamanho = Double.parseDouble(tamanhoInput.trim());

            // Quantidade
            String qtdInput = JOptionPane.showInputDialog(null,
                    "Digite a quantidade:", "Adicionar Produto", JOptionPane.PLAIN_MESSAGE);
            if (qtdInput == null) return;
            int quantidade = Integer.parseInt(qtdInput.trim());

            // Cria e adiciona o produto no estoque do proprietário atual
            Produto novoProduto = new Produto(nome, categoria, peso, tamanho, quantidade);
            proprietarioAtual.adicionarProduto(novoProduto);

            JOptionPane.showMessageDialog(null,
                    "Produto '" + nome + "' adicionado com sucesso!", "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                    "Valor numérico inválido. Use ponto (.) como separador decimal.", "ERRO",
                    JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage(), "ERRO",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ─── Opção 2: Listar Produtos ─────────────────────────────────

    private static void listarProdutos() {
        Estoque estoque = proprietarioAtual.getEstoque();

        if (estoque.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Você não possui produtos cadastrados.",
                    "Meus Produtos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(null, estoque.toStringListagem(),
                "Meus Produtos", JOptionPane.PLAIN_MESSAGE);
    }

    // ─── Opção 3: Buscar por Nome ─────────────────────────────────

    private static void buscarPorNome() {
        Estoque estoque = proprietarioAtual.getEstoque();

        if (estoque.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Você não possui produtos para buscar.",
                    "Buscar Produto", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String nomeBusca = JOptionPane.showInputDialog(null,
                "Digite o nome do produto para buscar:", "Buscar Produto", JOptionPane.PLAIN_MESSAGE);
        if (nomeBusca == null) return;

        Produto encontrado = estoque.buscarPorNome(nomeBusca.trim());

        if (encontrado != null) {
            JOptionPane.showMessageDialog(null,
                    "Produto encontrado!\n\n" + encontrado.toStringDetalhado(),
                    "Resultado da Busca", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                    "Produto '" + nomeBusca + "' não encontrado.",
                    "Resultado da Busca", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ─── Opção 4: Buscar por Categoria ───────────────────────────

    private static void buscarPorCategoria() {
        Estoque estoque = proprietarioAtual.getEstoque();

        if (estoque.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Você não possui produtos cadastrados.",
                    "Buscar por Categoria", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String inputCategoria = JOptionPane.showInputDialog(null,
                Categoria.listarCategorias(), "Buscar por Categoria", JOptionPane.PLAIN_MESSAGE);
        if (inputCategoria == null) return;

        try {
            Categoria categoria = Categoria.fromOpcao(Integer.parseInt(inputCategoria.trim()));
            if (categoria == null) {
                JOptionPane.showMessageDialog(null, "Categoria inválida.", "ERRO", JOptionPane.ERROR_MESSAGE);
                return;
            }

            var resultado = estoque.buscarPorCategoria(categoria);

            if (resultado.isEmpty()) {
                JOptionPane.showMessageDialog(null,
                        "Nenhum produto encontrado na categoria: " + categoria.getDescricao(),
                        "Resultado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                StringBuilder sb = new StringBuilder("Produtos em '" + categoria.getDescricao() + "':\n\n");
                for (Produto p : resultado) {
                    sb.append("• ").append(p.toString()).append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString(), "Resultado", JOptionPane.PLAIN_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Opção inválida.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ─── Opção 5: Realizar Troca ──────────────────────────────────

    /**
     * Simula uma troca entre o proprietário atual e um segundo proprietário fictício.
     *
     * NOTA: Em uma versão completa do sistema, haveria uma lista de proprietários
     * cadastrados e o usuário escolheria com quem trocar. Aqui criamos um
     * segundo proprietário para demonstrar o funcionamento da classe Troca.
     */
    private static void realizarTroca() {
        Estoque meuEstoque = proprietarioAtual.getEstoque();

        if (meuEstoque.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "Você precisa ter produtos cadastrados para realizar uma troca.",
                    "Realizar Troca", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Passo 1: qual produto o usuário quer oferecer?
            String nomeMeu = JOptionPane.showInputDialog(null,
                    "Qual produto você quer oferecer?\n\n" + meuEstoque.toStringListagem(),
                    "Realizar Troca", JOptionPane.PLAIN_MESSAGE);
            if (nomeMeu == null) return;

            Produto meuProduto = meuEstoque.buscarPorNome(nomeMeu.trim());
            if (meuProduto == null || !meuProduto.isDisponivel()) {
                JOptionPane.showMessageDialog(null,
                        "Produto '" + nomeMeu + "' não encontrado ou indisponível.", "ERRO",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Passo 2: dados do outro proprietário (simulado)
            // Numa versão real: buscar da lista de proprietários cadastrados
            JOptionPane.showMessageDialog(null,
                    "Agora informe os dados de quem possui o produto que você deseja.",
                    "Realizar Troca", JOptionPane.INFORMATION_MESSAGE);

            Proprietario outroProp = cadastrarProprietario();
            if (outroProp == null) return;

            // Passo 3: qual produto o usuário quer receber?
            String nomeDesejado = JOptionPane.showInputDialog(null,
                    "Qual o nome do produto que você deseja receber de " + outroProp.getNome() + "?",
                    "Realizar Troca", JOptionPane.PLAIN_MESSAGE);
            if (nomeDesejado == null) return;

            // Cria um produto fictício para o outro proprietário (simulação)
            Produto produtoDesejado = new Produto(nomeDesejado, Categoria.OUTROS, 1.0, 1.0, 1);
            outroProp.adicionarProduto(produtoDesejado);

            // Passo 4: cria a troca e exibe o resumo
            Troca troca = new Troca(proprietarioAtual, meuProduto, outroProp, produtoDesejado);

            int confirmacao = JOptionPane.showConfirmDialog(null,
                    troca.toStringDetalhado() + "\n\nDeseja confirmar esta troca?",
                    "Confirmar Troca", JOptionPane.YES_NO_OPTION);

            if (confirmacao == JOptionPane.YES_OPTION) {
                troca.confirmar();
                JOptionPane.showMessageDialog(null,
                        "Troca realizada com sucesso!\n\n" + troca.toStringDetalhado(),
                        "Troca Concluída", JOptionPane.INFORMATION_MESSAGE);
            } else {
                troca.cancelar();
                JOptionPane.showMessageDialog(null, "Troca cancelada.",
                        "Troca Cancelada", JOptionPane.WARNING_MESSAGE);
            }

        } catch (IllegalArgumentException | IllegalStateException e) {
            JOptionPane.showMessageDialog(null, "Erro na troca: " + e.getMessage(), "ERRO",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ─── Opção 6: Remover Produto ─────────────────────────────────

    private static void removerProduto() {
        Estoque estoque = proprietarioAtual.getEstoque();

        if (estoque.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Você não possui produtos para remover.",
                    "Remover Produto", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String nomeRemover = JOptionPane.showInputDialog(null,
                "Digite o nome do produto que deseja remover:\n\n" + estoque.toStringListagem(),
                "Remover Produto", JOptionPane.PLAIN_MESSAGE);
        if (nomeRemover == null) return;

        boolean removido = proprietarioAtual.removerProduto(nomeRemover.trim());

        if (removido) {
            JOptionPane.showMessageDialog(null,
                    "Produto '" + nomeRemover + "' removido com sucesso.", "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                    "Produto '" + nomeRemover + "' não encontrado.", "ERRO",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
