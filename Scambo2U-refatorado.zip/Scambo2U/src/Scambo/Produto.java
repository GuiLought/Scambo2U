package Scambo;

/**
 * Classe que representa um Produto no sistema Scambo2U.
 *
 * Cada produto pertence a um Proprietário e possui as
 * informações necessárias para ser exibido e trocado.
 */
public class Produto {

    // ─── Atributos ────────────────────────────────────────────────
    private String    nome;
    private Categoria categoria;
    private double    peso;      // em kg
    private double    tamanho;   // em cm
    private int       quantidade;

    // ─── Construtor ───────────────────────────────────────────────

    /**
     * Cria um novo produto com todos os dados obrigatórios.
     *
     * @param nome       Nome do produto (não pode ser vazio)
     * @param categoria  Categoria do produto (use o enum Categoria)
     * @param peso       Peso em kg (deve ser positivo)
     * @param tamanho    Tamanho em cm (deve ser positivo)
     * @param quantidade Quantidade disponível (deve ser >= 1)
     */
    public Produto(String nome, Categoria categoria, double peso, double tamanho, int quantidade) {
        setNome(nome);
        setCategoria(categoria);
        setPeso(peso);
        setTamanho(tamanho);
        setQuantidade(quantidade);
    }

    // ─── Getters e Setters ────────────────────────────────────────

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome do produto não pode ser vazio.");
        }
        this.nome = nome.trim();
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        if (categoria == null) {
            throw new IllegalArgumentException("A categoria do produto não pode ser nula.");
        }
        this.categoria = categoria;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        if (peso <= 0) {
            throw new IllegalArgumentException("O peso do produto deve ser maior que zero.");
        }
        this.peso = peso;
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        if (tamanho <= 0) {
            throw new IllegalArgumentException("O tamanho do produto deve ser maior que zero.");
        }
        this.tamanho = tamanho;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        if (quantidade < 0) {
            throw new IllegalArgumentException("A quantidade não pode ser negativa.");
        }
        this.quantidade = quantidade;
    }

    // ─── Métodos de negócio ───────────────────────────────────────

    /**
     * Verifica se o produto ainda está disponível para troca.
     */
    public boolean isDisponivel() {
        return quantidade > 0;
    }

    /**
     * Diminui a quantidade em 1 após uma troca.
     * Lança exceção se não houver estoque.
     */
    public void registrarTroca() {
        if (!isDisponivel()) {
            throw new IllegalStateException("Produto '" + nome + "' sem estoque para troca.");
        }
        this.quantidade--;
    }

    // ─── Exibição ─────────────────────────────────────────────────

    /**
     * Retorna uma descrição completa do produto para exibição em tela.
     */
    public String toStringDetalhado() {
        return "Nome: "       + nome                              + "\n"
             + "Categoria: "  + categoria.getDescricao()          + "\n"
             + "Peso: "       + String.format("%.2f", peso)       + " kg\n"
             + "Tamanho: "    + String.format("%.2f", tamanho)    + " cm\n"
             + "Quantidade: " + quantidade                         + "\n"
             + "Status: "     + (isDisponivel() ? "Disponível" : "Indisponível");
    }

    /**
     * Versão resumida para listagens.
     */
    @Override
    public String toString() {
        return nome + " [" + categoria.getDescricao() + "] - Qtd: " + quantidade;
    }
}
