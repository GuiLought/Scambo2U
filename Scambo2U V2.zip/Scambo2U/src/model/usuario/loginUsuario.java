package model.usuario;

public class loginUsuario {

	private int id;
	private String nome;
	private String email;
	private String senha;

	// Login padrão do usuário
	public static final String EMAIL_PADRAO = "user@scambo2u.com";
	public static final String SENHA_PADRAO = "user123";

	public loginUsuario(String nome, String email, String senha) {
		this.nome = nome;
		this.email = email;
		this.senha = senha;
	}

	// Getters e Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

}